const express = require('express');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser'); 
const PORT = 4001;

const db = require('./db/dbConfig');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.json());
app.use(cors());

app.listen(PORT,function(){
    db.query('SELECT * FROM events', function (error, results, fields) {
  if (error) throw error;
  console.log(results);
});
})

app.use('/',(req,res)=>{
    db.query('SELECT * FROM events', function (error, results, fields) {
        if (error) throw error;
        console.log(results);
        res.send(results);
      });
})