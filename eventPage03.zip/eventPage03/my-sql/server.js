const mysql = require('mysql');
const db = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '1234',
  database : 'events'
});
 
db.connect();
 
db.query('SELECT * FROM events', function (error, results, fields) {
  if (error) throw error;
  console.log(results);
});
 
db.end();