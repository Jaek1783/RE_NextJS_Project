import {useRouter}from 'next/router';
// import { getEventById } from '../../dummy-data';
import { getEventById, getFeaturedEvents } from '../../api-util';
import { Fragment } from 'react';
import Head from 'next/head';

import EventSummary from '../../components/event-detail/event-summary';
import EventLogistics from '../../components/event-detail/event-logistics';
import EventContent from '../../components/event-detail/event-content';
function EventDetailPage(props){
    //경로 세그먼트 데이터 추출
    const router = useRouter();
    const event = props.selectedEvent;
    console.log(event)

    //만약 수기로 경로를 입력했을 때 데이터가 없는 경우
    if(!event){
        return(
            <div className='center'>
                <p>Sorry No Data</p>
            </div>
        )
    }
    return(
        <Fragment>
            <Head>
                <title>{event.title}</title>
                <meta name="description"
                 content={event.description}/>
            </Head>            
            <EventSummary title={event.title}/>
            <EventLogistics 
                date={event.date}
                address={event.location} 
                image={event.image} 
                imageAlt={event.title}
            />
            <EventContent>
                <p>{event.description}</p>
            </EventContent>
        </Fragment>
    )
}

export async function getStaticProps(context){
const eventId = context.params.eventDetailPageId;
const event = await getEventById(eventId);
// const results = JSON.parse(JSON.stringify(event));

// console.log(eventId);
    return {
        props : {
            selectedEvent : event
        },
        revalidate :30
    };
}

export async function getStaticPaths(){
    const eventId = getFeaturedEvents();
    const paths = (await eventId).map(i => ({params : {eventDetailPageId : i.id}}));

    return{
        paths : paths,
        fallback: 'blocking'
    }
}
export default EventDetailPage;